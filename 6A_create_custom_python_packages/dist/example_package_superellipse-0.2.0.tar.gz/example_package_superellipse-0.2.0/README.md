This is a simple example package. You can use
refer to :" [here](https://packaging.python.org/en/latest/tutorials/packaging-projects/)

Demo Script:
Delete earlier Package version in dist
Change the .toml file for new version

pyenv --help
pyenv virtualenvs
pyenv activate test-cde

python3 -m build

python3 -m twine upload --repository testpypi dist/*
__token__
pypi-AgENdGVzdC5weXBpLm9yZwIkYmU2ZGRmZjEtNDQ5ZS00YWUzLWFjNzAtZTE1MzdjZmJlZmQ5AAIqWzMsIjJhNGYyY2ZjLTllNGEtNDViMi04NWM2LTIyZmE1ZjNhM2E1NyJdAAAGIDTnHBkapxZhUQJqHdNYKQK6YrvqXu5bpNAkMvEhap-6

SHOW THE Package in Pypi : https://test.pypi.org/project/example-package-superellipse/#history

cde resource create --name custom-pypi-02  --type python-env --python-version python3 --config-profile dbt-airflow-spark3