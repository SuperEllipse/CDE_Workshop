def add_one(number):
    return number + 1

def add_two(number):
    return number + 2

def add_three(number):
    return number + 2

def add_four(number):
    return number + 2

def mul_two(number):
    return number * 2

def mul_three(number):
    return number * 3

def mul_four(number):
    return number * 4